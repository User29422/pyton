import javax.swing.*;
import java.awt.*;

public class HomeWorkApp {

    public class FirstClass {

        public static void main(String[] args) {

        }
    }
        public static void main(String[] args) {
            System.out.print("Orange\n" +
                    "Banana\n" + "Apple");
        }

    public static void main(String[] args) {
    }

    public static void main(String[] args) {
        //numbers
        int a = 1;
        int b = 2;
        System.out.println("a + b");
        {
        }
        System.out.println("a + b = 0 ... 128 = Сумма положительная”) {
        if {
            System.out.println("a + b = 0,1 = Сумма отрицательная");
        }
    }
    public static void main(String[] args) {
        int value = 0;
         System.out.println("value = 0 = Красный");
         else {
             System.out.println("value = 1 ... 100 = Жёлтый ");
            else {
                System.out.println("value = 101 ... 2,147,483,647 = Зелёный");
            }
        }
    }
    public static void main(String[] args) {
        int a = 1;
        int b = 2;
        System.out.println("a > b = a >= b);
        else {
            System.out.println("a < b = a < b);
        }
    }
}

